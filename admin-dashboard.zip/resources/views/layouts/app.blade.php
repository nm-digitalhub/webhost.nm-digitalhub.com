<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" dir="{{ app()->getLocale() === 'he' ? 'rtl' : 'ltr' }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'NM-DigitalHUB') }}</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="font-sans antialiased">
        <!-- Navigation Bar -->
        <nav class="bg-white shadow-lg">
            <div class="max-w-7xl mx-auto px-4">
                <div class="flex justify-between">
                    <div class="flex space-x-7">
                        <div>
                            <!-- Website Logo -->
                            <a href="{{ route('home') }}" class="flex items-center py-4">
                                <span class="font-semibold text-gray-800 text-lg">NM-DigitalHUB</span>
                            </a>
                        </div>
                        <!-- Primary Navigation Menu -->
                        <div class="hidden md:flex items-center space-x-1">
                            <a href="{{ route('domains') }}" class="py-4 px-2 text-gray-500 hover:text-blue-500 transition duration-300">Domains</a>
                            <a href="{{ route('hosting') }}" class="py-4 px-2 text-gray-500 hover:text-blue-500 transition duration-300">Hosting</a>
                            <a href="{{ route('vps') }}" class="py-4 px-2 text-gray-500 hover:text-blue-500 transition duration-300">VPS</a>
                        </div>
                    </div>
                    <!-- Secondary Navigation Menu -->
                    <div class="hidden md:flex items-center space-x-3">
                        @auth
                            <a href="{{ route('dashboard') }}" class="py-2 px-4 text-white bg-blue-600 hover:bg-blue-700 transition duration-300 rounded">Dashboard</a>
                        @else
                            <a href="{{ route('login') }}" class="py-2 px-4 text-gray-800 hover:text-blue-500 transition duration-300">Log In</a>
                            <a href="{{ route('register') }}" class="py-2 px-4 text-white bg-blue-600 hover:bg-blue-700 transition duration-300 rounded">Sign Up</a>
                        @endauth
                    </div>
                    <!-- Mobile Menu Button -->
                    <div class="md:hidden flex items-center">
                        <button class="mobile-menu-button">
                            <svg class="w-6 h-6 text-gray-500 hover:text-blue-500" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor">
                                <path d="M4 6h16M4 12h16M4 18h16"></path>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu -->
            <div class="hidden mobile-menu md:hidden">
                <a href="{{ route('domains') }}" class="block py-2 px-4 text-sm text-gray-500 hover:bg-blue-50">Domains</a>
                <a href="{{ route('hosting') }}" class="block py-2 px-4 text-sm text-gray-500 hover:bg-blue-50">Hosting</a>
                <a href="{{ route('vps') }}" class="block py-2 px-4 text-sm text-gray-500 hover:bg-blue-50">VPS</a>
                @auth
                    <a href="{{ route('dashboard') }}" class="block py-2 px-4 text-sm text-gray-500 hover:bg-blue-50">Dashboard</a>
                @else
                    <a href="{{ route('login') }}" class="block py-2 px-4 text-sm text-gray-500 hover:bg-blue-50">Log In</a>
                    <a href="{{ route('register') }}" class="block py-2 px-4 text-sm text-gray-500 hover:bg-blue-50">Sign Up</a>
                @endauth
            </div>
        </nav>

        <div class="min-h-screen">
            @hasSection('content')
                @yield('content')
            @else
                <!-- Page Heading -->
                @isset($header)
                    <header class="bg-white shadow">
                        <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                            {{ $header }}
                        </div>
                    </header>
                @endisset

                <!-- Page Content from $slot -->
                <main>
                    {{ $slot ?? '' }}
                </main>
            @endif
        </div>

        <!-- Footer -->
        <footer class="bg-gray-800 text-white py-12">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                    <div>
                        <h3 class="text-lg font-semibold mb-4">NM-DigitalHUB</h3>
                        <p class="text-gray-400">Your one-stop solution for domains, hosting, and VPS services.</p>
                    </div>
                    <div>
                        <h4 class="text-md font-semibold mb-4">Services</h4>
                        <ul class="space-y-2">
                            <li><a href="{{ route('domains') }}" class="text-gray-400 hover:text-white transition">Domains</a></li>
                            <li><a href="{{ route('hosting') }}" class="text-gray-400 hover:text-white transition">Web Hosting</a></li>
                            <li><a href="{{ route('vps') }}" class="text-gray-400 hover:text-white transition">VPS Hosting</a></li>
                        </ul>
                    </div>
                    <div>
                        <h4 class="text-md font-semibold mb-4">Company</h4>
                        <ul class="space-y-2">
                            <li><a href="{{ route('home') }}#about" class="text-gray-400 hover:text-white transition">About Us</a></li>
                            <li><a href="{{ route('home') }}#contact" class="text-gray-400 hover:text-white transition">Contact</a></li>
                            <li><a href="{{ route('home') }}#faq" class="text-gray-400 hover:text-white transition">FAQ</a></li>
                        </ul>
                    </div>
                    <div>
                        <h4 class="text-md font-semibold mb-4">Legal</h4>
                        <ul class="space-y-2">
                            <li><a href="#terms" class="text-gray-400 hover:text-white transition">Terms of Service</a></li>
                            <li><a href="#privacy" class="text-gray-400 hover:text-white transition">Privacy Policy</a></li>
                        </ul>
                    </div>
                </div>
                <div class="mt-8 pt-8 border-t border-gray-700 text-center text-gray-400">
                    <p>&copy; {{ date('Y') }} NM-DigitalHUB. All rights reserved.</p>
                </div>
            </div>
        </footer>

        <script>
            // Mobile menu toggle
            document.addEventListener('DOMContentLoaded', function() {
                const btn = document.querySelector('.mobile-menu-button');
                const menu = document.querySelector('.mobile-menu');

                btn.addEventListener('click', function() {
                    menu.classList.toggle('hidden');
                });
            });
        </script>
    </body>
</html>
