<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Livewire\Admin\Dashboard as AdminDashboard;
use App\Http\Livewire\Client\Dashboard as ClientDashboard;
use App\Http\Livewire\Search;
use App\Http\Livewire\Domains;
use App\Http\Livewire\Hosting;
use App\Http\Livewire\Vps;
use App\Http\Middleware\IsAdmin;
use App\Http\Middleware\IsClient;




// עמוד הבית
Route::get('/', function () {
    $featuredDomains = ['example.com', 'domain.net', 'website.org'];
    return view('home', [
        'featuredDomains' => $featuredDomains,
    ]);
})->name('home');

// הפניה מ־/home ל־/
Route::get('/home', fn() => redirect()->route('home'));

// שירותי דומיינים והוסטינג
Route::get('/search', Search::class)->name('search');
Route::get('/domains', Domains::class)->name('domains');
Route::get('/hosting', Hosting::class)->name('hosting');
Route::get('/vps', Vps::class)->name('vps');

// דשבורד בסיסי למשתמשים מחוברים
Route::get('/dashboard', fn() => view('dashboard'))
    ->middleware(['auth', 'verified'])
    ->name('dashboard');

// נתיבי פרופיל
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// נתיבים למנהלים (admin)
Route::middleware(['auth', IsAdmin::class])->prefix('admin')->group(function () {
    Route::get('/dashboard', AdminDashboard::class)->name('admin.dashboard');
});

// נתיבים ללקוחות (client)
Route::middleware(['auth', IsClient::class])->prefix('client')->group(function () {
    Route::get('/dashboard', ClientDashboard::class)->name('client.dashboard');
});