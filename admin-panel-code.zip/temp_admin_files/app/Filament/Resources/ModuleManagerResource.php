<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ModuleManagerResource\Pages;
use App\Models\Module;
use App\Services\ModuleInstaller;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Support\Str;
use Filament\Tables\Actions\Action;
use Filament\Notifications\Notification;

class ModuleManagerResource extends Resource
{
    protected static ?string $model = Module::class;

    protected static ?string $navigationIcon = 'heroicon-o-puzzle-piece';
    protected static ?string $navigationGroup = 'ניהול מערכת';
    protected static ?string $modelLabel = 'מודול';
    protected static ?string $pluralModelLabel = 'מנהל מודולים';
    protected static ?int $navigationSort = 80;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Card::make()
                ->schema([
                    Forms\Components\TextInput::make('name')
                        ->label('שם המודול')
                        ->required()
                        ->maxLength(255)
                        ->afterStateUpdated(function (string $state, callable $set) {
                            if (!$set('slug')) {
                                $set('slug', Str::slug($state));
                            }
                        }),

                    Forms\Components\TextInput::make('slug')
                        ->label('Slug')
                        ->required()
                        ->maxLength(255)
                        ->unique(Module::class, 'slug', fn ($record) => $record),

                    Forms\Components\Textarea::make('description')
                        ->label('תיאור')
                        ->rows(3),

                    Forms\Components\TextInput::make('icon')
                        ->label('אייקון')
                        ->helperText('שם האייקון של Heroicon עם קידומת, למשל: heroicon-o-puzzle-piece')
                        ->maxLength(255),

                    Forms\Components\TextInput::make('version')
                        ->label('גרסה')
                        ->maxLength(255),

                    Forms\Components\Toggle::make('enabled')
                        ->label('פעיל')
                        ->default(true),

                    Forms\Components\KeyValue::make('meta')
                        ->label('מידע נוסף')
                        ->keyLabel('מפתח')
                        ->valueLabel('ערך')
                        ->keyPlaceholder('הכנס מפתח...')
                        ->valuePlaceholder('הכנס ערך...')
                        ->columnSpanFull(),
                ])
                ->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                // Status badge that combines enabled and installed status
                Tables\Columns\TextColumn::make('enabled')
                    ->label('סטטוס')
                    ->badge()
                    ->formatStateUsing(function (bool $state, Module $record): string {
                        if (!$state) {
                            return __('מושבת');
                        }
                        
                        return $record->installed_at 
                            ? __('פעיל') 
                            : __('ממתין להתקנה');
                    })
                    ->color(function (bool $state, Module $record): string {
                        if (!$state) {
                            return 'danger';
                        }
                        
                        return $record->installed_at ? 'success' : 'warning';
                    })
                    ->icon(function (bool $state, Module $record): string {
                        if (!$state) {
                            return 'heroicon-o-x-circle';
                        }
                        
                        return $record->installed_at 
                            ? 'heroicon-o-check-circle' 
                            : 'heroicon-o-clock';
                    })
                    ->alignment('center')
                    ->size('sm'),

                Tables\Columns\TextColumn::make('name')
                    ->label('שם המודול')
                    ->searchable()
                    ->sortable()
                    ->description(fn (Module $record) => Str::limit($record->description, 40))
                    ->wrap(),

                Tables\Columns\TextColumn::make('slug')
                    ->label('Slug')
                    ->searchable()
                    ->toggleable(fn () => ! auth()->user()->hasRole('super-admin')),

                Tables\Columns\TextColumn::make('version')
                    ->label('גרסה')
                    ->badge()
                    ->color('gray')
                    ->alignment('center')
                    ->size('sm'),

                Tables\Columns\TextColumn::make('installed_at')
                    ->label('תאריך התקנה')
                    ->dateTime()
                    ->sortable()
                    ->formatStateUsing(fn ($state) => $state ? $state->diffForHumans() : __('לא הותקן'))
                    ->color(fn ($state) => $state ? 'success' : 'gray')
                    ->toggleable(),

                Tables\Columns\TextColumn::make('created_at')
                    ->label('נוצר בתאריך')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(true),

                Tables\Columns\TextColumn::make('updated_at')
                    ->label('עודכן בתאריך')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(true),
            ])
            ->filters([
                Tables\Filters\TernaryFilter::make('enabled')
                    ->label('פעיל')
                    ->trueLabel('מודולים פעילים')
                    ->falseLabel('מודולים מושבתים')
                    ->placeholder('כל המודולים'),

                Tables\Filters\TernaryFilter::make('installed')
                    ->label('מותקן')
                    ->trueLabel('מודולים מותקנים')
                    ->falseLabel('מודולים לא מותקנים')
                    ->placeholder('כל המודולים')
                    ->queries(
                        true: fn ($query) => $query->whereNotNull('installed_at'),
                        false: fn ($query) => $query->whereNull('installed_at'),
                        blank: fn ($query) => $query
                    ),
            ])
            ->actions([
                Action::make('install')
                    ->label('התקן')
                    ->icon('heroicon-o-arrow-down-tray')
                    ->color('success')
                    ->visible(fn (Module $record) => is_null($record->installed_at))
                    ->action(function (Module $record) {
                        $installer = new ModuleInstaller();
                        $methodName = 'install' . ucfirst($record->slug) . 'Module';

                        if (method_exists($installer, $methodName)) {
                            $result = $installer->{$methodName}();

                            if ($result['success']) {
                                Notification::make()
                                    ->title('המודול הותקן בהצלחה')
                                    ->success()
                                    ->send();
                                return $result;
                            } else {
                                Notification::make()
                                    ->title('שגיאה בהתקנת המודול')
                                    ->body($result['message'])
                                    ->danger()
                                    ->send();
                                return $result;
                            }
                        } else {
                            Notification::make()
                                ->title('המודול אינו נתמך')
                                ->body('אין מתקין למודול ' . $record->name)
                                ->warning()
                                ->send();

                            return [
                                'success' => false,
                                'message' => 'No installer method found for ' . $record->slug . ' module.',
                            ];
                        }
                    }),

                Tables\Actions\EditAction::make()->label('ערוך'),

                Action::make('toggle')
                    ->label(fn (Module $record) => $record->enabled ? 'השבת' : 'הפעל')
                    ->icon(fn (Module $record) => $record->enabled ? 'heroicon-o-x-circle' : 'heroicon-o-check-circle')
                    ->color(fn (Module $record) => $record->enabled ? 'warning' : 'success')
                    ->requiresConfirmation()
                    ->action(function (Module $record) {
                        $record->update(['enabled' => !$record->enabled]);

                        Notification::make()
                            ->title($record->enabled ? 'המודול הופעל בהצלחה' : 'המודול הושבת בהצלחה')
                            ->success()
                            ->send();
                    }),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),

                    Tables\Actions\BulkAction::make('enable')
                        ->label('הפעל נבחרים')
                        ->icon('heroicon-o-check-circle')
                        ->color('success')
                        ->action(function (\Illuminate\Database\Eloquent\Collection $records) {
                            $records->each(fn (Module $record) => $record->update(['enabled' => true]));

                            Notification::make()
                                ->title('המודולים הופעלו בהצלחה')
                                ->success()
                                ->send();
                        }),

                    Tables\Actions\BulkAction::make('disable')
                        ->label('השבת נבחרים')
                        ->icon('heroicon-o-x-circle')
                        ->color('warning')
                        ->action(function (\Illuminate\Database\Eloquent\Collection $records) {
                            $records->each(fn (Module $record) => $record->update(['enabled' => false]));

                            Notification::make()
                                ->title('המודולים הושבתו בהצלחה')
                                ->success()
                                ->send();
                        }),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListModules::route('/'),
            'create' => Pages\CreateModule::route('/create'),
            'edit' => Pages\EditModule::route('/{record}/edit'),
        ];
    }
}