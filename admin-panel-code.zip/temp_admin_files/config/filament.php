<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Broadcasting (optional)
    |--------------------------------------------------------------------------
    */

    'broadcasting' => [

        // 'echo' => [
        //     'broadcaster' => 'pusher',
        //     'key' => env('VITE_PUSHER_APP_KEY'),
        //     'cluster' => env('VITE_PUSHER_APP_CLUSTER'),
        //     'wsHost' => env('VITE_PUSHER_HOST'),
        //     'wsPort' => env('VITE_PUSHER_PORT'),
        //     'wssPort' => env('VITE_PUSHER_PORT'),
        //     'authEndpoint' => '/broadcasting/auth',
        //     'disableStats' => true,
        //     'encrypted' => true,
        //     'forceTLS' => true,
        // ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Default Filesystem Disk
    |--------------------------------------------------------------------------
    */

    'default_filesystem_disk' => env('FILAMENT_FILESYSTEM_DISK', 'public'),

    /*
    |--------------------------------------------------------------------------
    | Assets Path
    |--------------------------------------------------------------------------
    */

    'assets_path' => 'assets/filament',

    /*
    |--------------------------------------------------------------------------
    | Cache Path
    |--------------------------------------------------------------------------
    */

    'cache_path' => base_path('bootstrap/cache/filament'),

    /*
    |--------------------------------------------------------------------------
    | Livewire Loading Delay
    |--------------------------------------------------------------------------
    */

    'livewire_loading_delay' => 'default',

    /*
    |--------------------------------------------------------------------------
    | System Route Prefix
    |--------------------------------------------------------------------------
    */

    'system_route_prefix' => 'admin-system',

    /*
    |--------------------------------------------------------------------------
    | Brand
    |--------------------------------------------------------------------------
    |
    | שמות קבצי הלוגו כאן נכתבים כמחרוזת טקסט יחסית ל־public/, ולא בעזרת asset()
    | כדי למנוע שגיאות בעת הרצת artisan commands (כמו vendor:publish).
    |
    */

    'brand' => [
        'name' => 'NM DigitalHUB',
        'logo' => 'assets/logo/nm-logo-full-color.png',
        'favicon' => 'assets/logo/nm-icon-color.png',
    ],

    /*
    |--------------------------------------------------------------------------
    | Appearance & Layout
    |--------------------------------------------------------------------------
    */

    'dark_mode' => true,

    'layout' => [
        'direction' => 'rtl',
        'max_content_width' => '7xl',
        'sidebar' => [
            'collapsed_by_default' => false,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Fonts (optional custom font like Heebo)
    |--------------------------------------------------------------------------
    */

    'fonts' => [
        'default' => 'Heebo, sans-serif',
    ],
];
