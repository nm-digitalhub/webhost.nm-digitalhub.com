<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Livewire\Admin\Dashboard as AdminDashboard;
use App\Livewire\Client\Dashboard as ClientDashboard;
use App\Livewire\Search;
use App\Livewire\Domains;
use App\Livewire\Hosting;
use App\Livewire\Vps;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LanguageController;
use App\Http\Controllers\GoogleOAuthController;
use App\Http\Middleware\IsAdmin;
use App\Http\Middleware\IsClient;
use App\Http\Middleware\SetLocale;

// Apply SetLocale middleware to all routes
Route::middleware([SetLocale::class])->group(function () {
    // Language switcher route
    Route::get('/lang/{locale}', [LanguageController::class, 'switchLang'])->name('lang.switch');

    // עמוד הבית - now supports CMS integration
    Route::get('/', [App\Http\Controllers\PageController::class, 'home'])->name('home');

    // הפניה מ־/home ל־/
    Route::redirect('/home', '/');

    // חיפוש דומיינים והוסטינג
    Route::post('/search', [HomeController::class, 'search'])->name('search');

    // Service pages - now with CMS integration
    Route::get('/domains', [App\Http\Controllers\PageController::class, 'servicePage'])->name('domains')->defaults('type', 'domains');
    Route::get('/hosting', [App\Http\Controllers\PageController::class, 'servicePage'])->name('hosting')->defaults('type', 'hosting');
    Route::get('/vps', [App\Http\Controllers\PageController::class, 'servicePage'])->name('vps')->defaults('type', 'vps');
    Route::get('/cloud', [App\Http\Controllers\PageController::class, 'servicePage'])->name('cloud')->defaults('type', 'cloud');

    // טופס יצירת קשר
    Route::post('/contact', [HomeController::class, 'contactSubmit'])->name('contact.submit');
Route::get('login', [AuthenticatedSessionController::class, 'create'])
    ->name('login');


    // עמודי מידע - now with CMS integration
    Route::get('/terms', [App\Http\Controllers\PageController::class, 'terms'])->name('terms');
    Route::get('/policy', [App\Http\Controllers\PageController::class, 'policy'])->name('policy');

    // דשבורד למשתמשים מחוברים
    Route::middleware(['auth', 'verified'])->group(function () {
        Route::get('/dashboard', [HomeController::class, 'dashboard'])->name('dashboard');
        Route::get('/profile', [HomeController::class, 'profile'])->name('profile');
        Route::get('/settings', [HomeController::class, 'settings'])->name('settings');
    });

    // נתיבי ניהול פרופיל
    Route::middleware('auth')->group(function () {
        Route::get('/profile/edit', [ProfileController::class, 'edit'])->name('profile.edit');
        Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
        Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    });

    // Google OAuth Routes
    Route::prefix('oauth/google')->name('oauth.google.')->group(function () {
        Route::get('/redirect', [GoogleOAuthController::class, 'redirect'])->name('redirect');
        Route::get('/callback', [GoogleOAuthController::class, 'callback'])->name('callback');
    });

    // פאנל מנהלים
    Route::middleware(['auth', IsAdmin::class])->prefix('admin')->name('admin.')->group(function () {
        Route::get('/dashboard', AdminDashboard::class)->name('dashboard');

        Route::get('/users-legacy', \App\Http\Livewire\Admin\Users::class)->name('admin.users.legacy');
        Route::get('/domains', \App\Http\Livewire\Admin\Domains::class)->name('domains');
        Route::get('/domains/new', \App\Livewire\Admin\DomainsNew::class)->name('domains.new');
        Route::get('/hosting', \App\Http\Livewire\Admin\Hosting::class)->name('hosting');
        Route::get('/vps', \App\Http\Livewire\Admin\Vps::class)->name('vps');
        Route::get('/invoices', \App\Http\Livewire\Admin\Invoices::class)->name('invoices');
        Route::get('/plans', \App\Http\Livewire\Admin\Plans::class)->name('plans');
        Route::get('/orders', \App\Http\Livewire\Admin\Orders::class)->name('orders');
        Route::get('/tickets', \App\Http\Livewire\Admin\Tickets::class)->name('tickets');
        Route::get('/settings', \App\Http\Livewire\Admin\Settings::class)->name('settings');
    });

    // פאנל לקוחות
    Route::middleware(['auth', IsClient::class])->prefix('client')->name('client.')->group(function () {
        // Dashboard route
        Route::get('/dashboard', ClientDashboard::class)->name('dashboard');

        // Legacy routes - these will be replaced by dynamic modules
        Route::get('/domains', \App\Livewire\Client\Domains::class)->name('domains');
        Route::get('/domains/check', \App\Livewire\Client\DomainCheck::class)->name('domains.check');

        Route::get('/hosting', \App\Livewire\Client\Hosting::class)->name('hosting');
        Route::get('/hosting/new', \App\Livewire\Client\HostingNew::class)->name('hosting.new');

        Route::get('/vps', \App\Livewire\Client\Vps::class)->name('vps');

        Route::get('/invoices', \App\Livewire\Client\Invoices::class)->name('invoices');
        Route::get('/settings', \App\Livewire\Client\Settings::class)->name('settings');

        // Profile route
        Route::get('/profile', [\App\Http\Controllers\Client\ClientController::class, 'profile'])->name('profile');

        // Payment methods route
        Route::get('/payment-methods', [\App\Http\Controllers\Client\ClientController::class, 'paymentMethods'])->name('payment-methods');

        Route::get('/support', \App\Livewire\Client\Support::class)->name('support');
        Route::get('/support/new', \App\Livewire\Client\SupportNew::class)->name('support.new');

        // Ajax routes for dynamic client actions
        Route::post('/toggle-auto-renewal', [\App\Http\Controllers\Client\ClientController::class, 'toggleAutoRenewal'])
            ->name('toggle-auto-renewal');
        Route::post('/update-currency', [\App\Http\Controllers\Client\ClientController::class, 'updateCurrency'])
            ->name('update-currency');

        // Module installer test routes - would be removed in production
        Route::get('/modules', [\App\Http\Controllers\Client\ClientController::class, 'showModules'])->name('modules');

        // DNS Management route for domains module
        Route::get('/dns-management', [\App\Http\Controllers\Client\DomainController::class, 'dnsManagement'])
            ->name('dns-management');

        // Domain search route
        Route::get('/domain-search', [\App\Http\Controllers\Client\DomainController::class, 'domainSearch'])
            ->name('domain-search');

        // Knowledge base route
        Route::get('/knowledge-base', [\App\Http\Controllers\Client\SupportController::class, 'knowledgeBase'])
            ->name('knowledge-base');

        // Tickets route
        Route::get('/tickets', [\App\Http\Controllers\Client\SupportController::class, 'tickets'])
            ->name('tickets');

        // Subscriptions route
        Route::get('/subscriptions', [\App\Http\Controllers\Client\BillingController::class, 'subscriptions'])
            ->name('subscriptions');

        // Statistics route
        Route::get('/statistics', [\App\Http\Controllers\Client\ClientController::class, 'statistics'])
            ->name('statistics');

        // Dynamic client pages route - catch-all for custom pages
        Route::get('/pages/{slug}', [\App\Http\Controllers\Client\ClientController::class, 'showPage'])
            ->name('pages.show');
    });

    // Generic page route - must be at the end to avoid conflicts
    Route::get('/page/{slug}', [App\Http\Controllers\PageController::class, 'show'])->name('pages.show');

}); // כאן מסתיים Route::middleware([SetLocale::class])

// ✅ הוסף כאן ולא בתוך ה־group
require __DIR__.'/auth.php';
// Include impersonation routes
require __DIR__.'/web_impersonation.php';
