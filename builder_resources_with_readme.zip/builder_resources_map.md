# Builder Resource Mapping

המסמך מפרט את הקבצים שנארזו ומציג את תפקידם, מיקומם וניתוביהם במערכת Filament.

## קובץ: app/Filament/Resources/ModuleManagerResource.php
- **מחלקה**: `ModuleManagerResource`
- **ניתובים**:
  - '/'
  - '/create'
  - '/{record}/edit'
- תיאור כללי: ModuleManagerResource.php קובץ המייצג רכיב בפאנל Filament (Resource/Page/Provider)

## קובץ: app/Filament/Resources/GeneratorResource.php
- **מחלקה**: `GeneratorResource`
- **ניתובים**:
  - 'filament.admin.resources.generators.generate', $record)
  - '/'
  - '/create'
  - '/{record}/edit'
  - '/{record}/generate'
- תיאור כללי: GeneratorResource.php קובץ המייצג רכיב בפאנל Filament (Resource/Page/Provider)

## קובץ: app/Filament/Resources/ClientModuleResource.php
- **מחלקה**: `ClientModuleResource`
- **ניתובים**:
  - '/'
  - '/create'
  - '/{record}/edit'
- תיאור כללי: ClientModuleResource.php קובץ המייצג רכיב בפאנל Filament (Resource/Page/Provider)

## קובץ: app/Filament/Resources/ModuleManagerResource/Pages/ListModules.php
- **מחלקה**: `ListModules`
- אין ניתובים מפורשים בקובץ זה.
- תיאור כללי: ListModules.php קובץ המייצג רכיב בפאנל Filament (Resource/Page/Provider)

## קובץ: app/Filament/Resources/GeneratorResource/Pages/ListGenerators.php
- **מחלקה**: `ListGenerators`
- אין ניתובים מפורשים בקובץ זה.
- תיאור כללי: ListGenerators.php קובץ המייצג רכיב בפאנל Filament (Resource/Page/Provider)

## קובץ: app/Providers/Filament/AdminPanelProvider.php
- **מחלקה**: `AdminPanelProvider`
- אין ניתובים מפורשים בקובץ זה.
- תיאור כללי: AdminPanelProvider.php קובץ המייצג רכיב בפאנל Filament (Resource/Page/Provider)

