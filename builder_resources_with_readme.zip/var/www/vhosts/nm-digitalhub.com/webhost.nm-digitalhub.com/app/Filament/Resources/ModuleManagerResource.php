<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ModuleManagerResource\Pages;
use App\Models\ModuleManager;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables\Table;
use Filament\Tables;
use Illuminate\Database\Eloquent\Builder;

class ModuleManagerResource extends Resource
{
    protected static ?string $model = ModuleManager::class;

    protected static ?string $navigationGroup = 'מנהל מודולים';
    protected static ?string $modelLabel = 'ניהול מודולים';
    protected static ?string $pluralModelLabel = 'מודולים';

    public static function shouldRegisterNavigation(): bool
    {
        return true;
    }

    public static function form(Form $form): Form
    {
        return $form->schema([]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([]);
    }

    public static function getRelations(): array
    {
        return [];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListModuleManagers::route('/'),
            'create' => Pages\CreateModuleManager::route('/create'),
            'edit' => Pages\EditModuleManager::route('/{record}/edit'),
        ];
    }
}