<?php
<?php

namespace App\Livewire\Client;

use Livewire\Component;
use Livewire\WithPagination;

class Vps extends Component
{
    use WithPagination;

    protected $paginationTheme = 'tailwind';

    public $search = '';
    public $status = '';
    public $sortField = 'created_at';
    public $sortDirection = 'desc';

    protected $queryString = [
        'search' => ['except' => ''],
        'status' => ['except' => ''],
        'sortField' => ['except' => 'created_at'],
        'sortDirection' => ['except' => 'desc'],
    ];

    public function sortBy($field)
    {
        if ($this->sortField === $field) {
            $this->sortDirection = $this->sortDirection === 'asc' ? 'desc' : 'asc';
        } else {
            $this->sortDirection = 'asc';
        }

        $this->sortField = $field;
    }

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function updatingStatus()
    {
        $this->resetPage();
    }

    public function render()
    {
        // In a real application, this would fetch VPS servers from the database
        // $vpsServers = VpsServer::whereUserId(auth()->id())
        //     ->when($this->search, function($query, $search) {
        //         return $query->where('name', 'like', "%{$search}%")
        //             ->orWhere('ip', 'like', "%{$search}%");
        //     })
        //     ->when($this->status, fn($query, $status) => $query->where('status', $status))
        //     ->orderBy($this->sortField, $this->sortDirection)
        //     ->paginate(10);

        // Demo data for now
        $vpsServers = [];

        return view('livewire.client.vps', [
            'vpsServers' => $vpsServers,
        ])->layout('livewire.client.layout');
    }
}
namespace App\Livewire\Client;

use Livewire\Component;

class Vps extends Component
{
    public function render()
    {
        return view('livewire.client.vps')
            ->layout('layouts.client');
    }
}
