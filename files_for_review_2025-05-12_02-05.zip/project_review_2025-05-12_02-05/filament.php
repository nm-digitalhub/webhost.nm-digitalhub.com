<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Broadcasting
    |--------------------------------------------------------------------------
    |
    | By uncommenting the Laravel Echo configuration, you may connect Filament
    | to any Pusher-compatible websockets server.
    |
    | This will allow your application to receive real-time notifications.
    |
    */

    'broadcasting' => [
        // 'echo' => [
        //     'broadcaster' => 'pusher',
        //     'key' => env('VITE_PUSHER_APP_KEY'),
        //     'cluster' => env('VITE_PUSHER_APP_CLUSTER'),
        //     'wsHost' => env('VITE_PUSHER_HOST'),
        //     'wsPort' => env('VITE_PUSHER_PORT'),
        //     'wssPort' => env('VITE_PUSHER_PORT'),
        //     'authEndpoint' => '/broadcasting/auth',
        //     'disableStats' => true,
        //     'encrypted' => true,
        //     'forceTLS' => true,
        // ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Default Filesystem Disk
    |--------------------------------------------------------------------------
    */

    'storage_disk' => env('FILAMENT_STORAGE_DISK', 'public'),

    /*
    |--------------------------------------------------------------------------
    | Assets Path
    |--------------------------------------------------------------------------
    */

    'assets_path' => 'assets/filament',

    /*
    |--------------------------------------------------------------------------
    | Cache Path
    |--------------------------------------------------------------------------
    */

    'cache_path' => base_path('bootstrap/cache/filament'),

    /*
    |--------------------------------------------------------------------------
    | Livewire Loading Delay
    |--------------------------------------------------------------------------
    */

    'livewire_loading_delay' => 'default',

    /*
    |--------------------------------------------------------------------------
    | System Route Prefix
    |--------------------------------------------------------------------------
    */

    'system_route_prefix' => 'admin-system',

    /*
    |--------------------------------------------------------------------------
    | Panels
    |--------------------------------------------------------------------------
    |
    | Panels allow you to customize Filament.
    |
    */

    'panels' => [
        'default' => [
            'path' => 'admin',
            'domain' => null,
            'tenant' => null,
            'middleware' => [
                \Illuminate\Cookie\Middleware\EncryptCookies::class,
                \Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse::class,
                \Illuminate\Session\Middleware\StartSession::class,
                \Illuminate\View\Middleware\ShareErrorsFromSession::class,
                \Illuminate\Foundation\Http\Middleware\VerifyCsrfToken::class,
                \Illuminate\Routing\Middleware\SubstituteBindings::class,
                \Filament\Http\Middleware\Authenticate::class,
                \Filament\Http\Middleware\DisableBladeIconComponents::class,
                \Filament\Http\Middleware\DispatchServingFilamentEvent::class,
            ],
            'navigation' => [
                'collapsible' => true,
                'collapsibleOnDesktop' => false,
                'groups' => [
                    'are_collapsible' => true,
                ],
            ],
            'auth' => [
                'guard' => env('FILAMENT_AUTH_GUARD', 'web'),
                'pages' => [
                    'login' => \Filament\Pages\Auth\Login::class,
                ],
            ],
            'pages' => [
                'dashboard' => \Filament\Pages\Dashboard::class,
            ],
            'widgets' => [
                \Filament\Widgets\AccountWidget::class,
                \Filament\Widgets\FilamentInfoWidget::class,
            ],
            'default_avatar_provider' => \Filament\AvatarProviders\UiAvatarsProvider::class,
            'sidebarWidth' => '16rem',
            'sidebarCollapsibleOnDesktop' => true,
            'unsaved_changes_alert' => true,
            'database_notifications' => [
                'enabled' => true,
                'polling_interval' => '30s',
            ],
            'dusk' => [
                'register_route' => true,
                'enabled' => env('FILAMENT_DUSK', true),
            ],
            'dark_mode' => [
                'enabled' => true,
            ],
            'spa' => false,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Icons
    |--------------------------------------------------------------------------
    */

    'icons' => [
        'style' => 'heroicon-o',
        'size' => 'md',
    ],

    /*
    |--------------------------------------------------------------------------
    | Brand
    |--------------------------------------------------------------------------
    */

    'brand' => [
        'name' => 'NM DigitalHUB',
        'logo' => 'assets/logo/nm-logo-full-color.png',
        'favicon' => 'assets/logo/nm-icon-color.png',
    ],

    /*
    |--------------------------------------------------------------------------
    | Appearance & Layout
    |--------------------------------------------------------------------------
    */

    'dark_mode' => true,

    'layout' => [
        'direction' => 'rtl',
        'max_content_width' => '7xl',
        'sidebar' => [
            'collapsed_by_default' => false,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Fonts
    |--------------------------------------------------------------------------
    */

    'fonts' => [
        'default' => 'Heebo, sans-serif',
    ],
];
