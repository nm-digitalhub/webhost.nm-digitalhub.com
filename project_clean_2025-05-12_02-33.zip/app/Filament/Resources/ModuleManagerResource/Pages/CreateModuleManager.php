<?php

namespace App\Filament\Resources\ModuleManagerResource\Pages;

use Filament\Resources\Pages\CreateRecord;
use App\Filament\Resources\ModuleManagerResource;

class CreateModuleManager extends CreateRecord
{
    protected static string $resource = ModuleManagerResource::class;
}