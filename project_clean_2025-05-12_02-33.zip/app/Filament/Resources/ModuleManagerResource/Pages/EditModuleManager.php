<?php

namespace App\Filament\Resources\ModuleManagerResource\Pages;

use Filament\Resources\Pages\EditRecord;
use App\Filament\Resources\ModuleManagerResource;

class EditModuleManager extends EditRecord
{
    protected static string $resource = ModuleManagerResource::class;
}