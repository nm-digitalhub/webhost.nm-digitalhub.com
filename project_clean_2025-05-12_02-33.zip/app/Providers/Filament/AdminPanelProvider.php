<?php

namespace App\Providers\Filament;

use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\AuthenticateSession;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;
use Filament\Pages\Dashboard;
use Filament\Widgets\AccountWidget;
use Filament\Widgets\FilamentInfoWidget;

use App\Filament\Widgets\UsersStatsWidget;
use App\Filament\Widgets\ModulesStatsWidget;
use App\Filament\Widgets\SystemResourcesWidget;
use App\Filament\Widgets\LatestActivityWidget;
use App\Filament\Widgets\SystemHealthWidget;

class AdminPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->id('admin')
            ->path('admin')
            ->colors([
                'primary' => Color::Blue,
                'info' => Color::Sky,
                'success' => Color::Emerald,
                'warning' => Color::Orange,
                'danger' => Color::Rose,
            ])
            ->font('Inter')
            ->favicon(asset('images/logo-256x256.png'))
            ->sidebarFullyCollapsibleOnDesktop()
            ->collapsibleNavigationGroups()
            ->darkMode(true)
            ->brandLogo(asset('images/logo-primary.png'))
            ->brandLogoHeight('2.5rem')
            ->navigationGroups([
                'ניהול מערכת',
                'ניהול משתמשים',
                'ניהול תוכן',
                'הגדרות',
            ])
            ->databaseNotifications()
            ->globalSearch()

            // רישום כל המשאבים
            ->resources([
                \App\Filament\Admin\Resources\UserResource::class,
                \App\Filament\Admin\Resources\RoleResource::class,
                \App\Filament\Resources\GeneratorResource::class,
                \App\Filament\Resources\GenerationLogResource::class,
                \App\Filament\Resources\PageResource::class,
                \App\Filament\Resources\MailSettingResource::class,
                \App\Filament\Resources\MailTemplateResource::class,

                // נוספו עכשיו
                \App\Filament\Resources\ClientPageResource::class,
                \App\Filament\Resources\ClientModuleResource::class,
                \App\Filament\Resources\ProductResource::class,
                \App\Filament\Resources\ModuleManagerResource::class,
            ])

            ->discoverResources(in: app_path('Filament/Resources'), for: 'App\\Filament\\Resources')

            ->pages([
                Dashboard::class,
            ])
            ->discoverPages(in: app_path('Filament/Pages'), for: 'App\\Filament\\Pages')

            ->widgets([
                UsersStatsWidget::class,
                ModulesStatsWidget::class,
                SystemResourcesWidget::class,
                LatestActivityWidget::class,
                SystemHealthWidget::class,
                AccountWidget::class,
                FilamentInfoWidget::class,
            ])
            ->discoverWidgets(in: app_path('Filament/Widgets'), for: 'App\\Filament\\Widgets')

            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                VerifyCsrfToken::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([
                Authenticate::class,
            ]);
    }
}