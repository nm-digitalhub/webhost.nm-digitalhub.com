<div <?php echo e($attributes->class(['fi-dropdown-list p-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /var/www/vhosts/nm-digitalhub.com/webhost.nm-digitalhub.com/vendor/filament/support/src/../resources/views/components/dropdown/list/index.blade.php ENDPATH**/ ?>