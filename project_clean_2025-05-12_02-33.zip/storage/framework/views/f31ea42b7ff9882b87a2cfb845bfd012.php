<?php if (isset($component)) { $__componentOriginalbbf8e3d93c323969dbe221daff2ff27e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbbf8e3d93c323969dbe221daff2ff27e = $attributes; } ?>
<?php $component = App\View\Components\KpiSummaryBar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-summary-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\KpiSummaryBar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbbf8e3d93c323969dbe221daff2ff27e)): ?>
<?php $attributes = $__attributesOriginalbbf8e3d93c323969dbe221daff2ff27e; ?>
<?php unset($__attributesOriginalbbf8e3d93c323969dbe221daff2ff27e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbbf8e3d93c323969dbe221daff2ff27e)): ?>
<?php $component = $__componentOriginalbbf8e3d93c323969dbe221daff2ff27e; ?>
<?php unset($__componentOriginalbbf8e3d93c323969dbe221daff2ff27e); ?>
<?php endif; ?>

<div class="mb-4">
    <div class="flex flex-wrap items-center justify-between gap-4">
        <div>
            <h2 class="text-xl font-bold tracking-tight md:text-2xl">
                <?php echo e(__('Welcome to NM-DigitalHUB Admin')); ?>

            </h2>
            
            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                <?php echo e(__('Monitor your system metrics and manage resources efficiently')); ?>

            </p>
        </div>
        
        <div class="flex items-center gap-4">
            <div class="hidden md:flex items-center gap-2">
                <span class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Server Time')); ?>:</span>
                <span class="text-sm font-medium"><?php echo e(now()->format('H:i')); ?></span>
            </div>
            
            <!-- Mobile responsive action buttons -->
            <div class="flex flex-wrap items-center gap-2">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="filament-button filament-button-size-sm inline-flex items-center justify-center gap-1 font-medium rounded-lg border transition-colors focus:outline-none focus:ring-offset-2 focus:ring-2 focus:ring-inset dark:focus:ring-offset-0 min-h-8 px-3 text-sm text-gray-800 bg-white border-gray-300 hover:bg-gray-50 dark:text-white dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-arrow-path'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                    <span class="hidden sm:inline"><?php echo e(__('Refresh')); ?></span>
                </a>
                
                <a href="<?php echo e(route('admin.settings')); ?>" class="filament-button filament-button-size-sm inline-flex items-center justify-center gap-1 font-medium rounded-lg border transition-colors focus:outline-none focus:ring-offset-2 focus:ring-2 focus:ring-inset dark:focus:ring-offset-0 min-h-8 px-3 text-sm text-gray-800 bg-white border-gray-300 hover:bg-gray-50 dark:text-white dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-cog-6-tooth'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                    <span class="hidden sm:inline"><?php echo e(__('Settings')); ?></span>
                </a>
            </div>
        </div>
    </div>
</div><?php /**PATH /var/www/vhosts/nm-digitalhub.com/webhost.nm-digitalhub.com/resources/views/filament/pages/dashboard-header.blade.php ENDPATH**/ ?>