<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ClientModuleResource\Pages;
use App\Models\ClientModule;

use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
use Spatie\Permission\Models\Permission;

class ClientModuleResource extends Resource
{
    protected static ?string $model = ClientModule::class;

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-group';

    protected static ?string $navigationGroup = 'ניהול פאנל לקוחות';

    protected static ?string $modelLabel = 'מודול לקוח';

    protected static ?string $pluralModelLabel = 'מודולים לקוחות';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Tabs::make('module_tabs')
                    ->tabs([
                        Forms\Components\Tabs\Tab::make('basic_settings')
                            ->label('הגדרות בסיסיות')
                            ->schema([
                                Forms\Components\TextInput::make('name')
                                    ->label('שם המודול')
                                    ->required()
                                    ->maxLength(255)
                                    ->live(onBlur: true)
                                    ->afterStateUpdated(function (string $state, callable $set) {
                                        $set('slug', Str::slug($state));
                                    }),

                                Forms\Components\TextInput::make('slug')
                                    ->label('Slug')
                                    ->required()
                                    ->unique(ignoreRecord: true)
                                    ->maxLength(255),

                                Forms\Components\TextInput::make('icon')
                                    ->label('אייקון')
                                    ->helperText('שם האייקון של Heroicon (למשל: heroicon-o-home)')
                                    ->maxLength(255),

                                Forms\Components\Select::make('type')
                                    ->label('סוג')
                                    ->options([
                                        'section' => 'חלק/כותרת',
                                        'page' => 'עמוד/דף',
                                        'link' => 'קישור חיצוני',
                                    ])
                                    ->default('page')
                                    ->required(),

                                Forms\Components\Toggle::make('enabled')
                                    ->label('פעיל')
                                    ->default(true),

                                Forms\Components\TextInput::make('position')
                                    ->label('סדר הצגה')
                                    ->numeric()
                                    ->default(0),

                                Forms\Components\Textarea::make('description')
                                    ->label('תיאור')
                                    ->maxLength(65535)
                                    ->columnSpanFull(),
                            ]),

                        Forms\Components\Tabs\Tab::make('routes_settings')
                            ->label('הגדרות ניתוב')
                            ->schema([
                                Forms\Components\TextInput::make('route_name')
                                    ->label('שם הנתיב')
                                    ->helperText('שם הנתיב בפורמט client.{route}'),

                                Forms\Components\TextInput::make('component_class')
                                    ->label('מחלקת Component')
                                    ->helperText('נתיב מלא למחלקת Livewire/Filament (למשל: App\Http\Livewire\Client\Dashboard)')
                                    ->maxLength(255),

                                Forms\Components\Select::make('layout')
                                    ->label('תבנית עיצוב')
                                    ->options([
                                        'default' => 'ברירת מחדל',
                                        'full-width' => 'רוחב מלא',
                                        'sidebar-left' => 'סרגל צד שמאל',
                                        'sidebar-right' => 'סרגל צד ימין',
                                    ])
                                    ->default('default'),
                            ]),

Forms\Components\Tabs\Tab::make('permissions_settings')
    ->label('הרשאות')
    ->schema([
        Forms\Components\CheckboxList::make('permission_restrictions')
            ->label('הגבלת הרשאות')
            ->helperText('בחר את ההרשאות שצריכות להיות למשתמש כדי שיוכל לראות את המודול הזה')
            ->options(fn () => Permission::pluck('name', 'name')->toArray())
            ->columns(2),

        Forms\Components\KeyValue::make('permissions')
            ->label('הרשאות ספציפיות')
            ->keyLabel('הרשאה')
            ->valueLabel('ערך')
            ->columnSpanFull(),
    ]), // ← סגירת ה-TAB בפסיק!
                                    


                        Forms\Components\Tabs\Tab::make('advanced_settings')
                            ->label('הגדרות מתקדמות')
                            ->schema([
                                Forms\Components\KeyValue::make('metadata')
                                    ->label('מטא-דאטה')
                                    ->keyLabel('מפתח')
                                    ->valueLabel('ערך')
                                    ->columnSpanFull(),
                            ]),
                    ])
                    ->columnSpanFull(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')
                    ->label('שם')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('slug')
                    ->label('Slug')
                    ->searchable(),

                Tables\Columns\IconColumn::make('enabled')
                    ->label('פעיל')
                    ->boolean(),

                Tables\Columns\BadgeColumn::make('type')
                    ->label('סוג')
                    ->colors([
                        'primary' => 'page',
                        'secondary' => 'section',
                        'warning' => 'link',
                    ])
                    ->sortable(),

                Tables\Columns\TextColumn::make('position')
                    ->label('סדר')
                    ->numeric()
                    ->sortable(),

                Tables\Columns\TextColumn::make('created_at')
                    ->label('נוצר בתאריך')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(true),

                Tables\Columns\TextColumn::make('updated_at')
                    ->label('עודכן בתאריך')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(true),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('type')
                    ->label('סוג')
                    ->options([
                        'section' => 'חלק/כותרת',
                        'page' => 'עמוד/דף',
                        'link' => 'קישור חיצוני',
                    ]),

                Tables\Filters\TernaryFilter::make('enabled')
                    ->label('פעיל'),
            ])
            ->actions([
                Tables\Actions\ActionGroup::make([
                    Tables\Actions\ViewAction::make(),
                    Tables\Actions\EditAction::make(),
                    Tables\Actions\DeleteAction::make(),
                    Tables\Actions\Action::make('toggle_status')
                        ->label(fn (ClientModule $record): string => $record->enabled ? 'השבת' : 'הפעל')
                        ->icon(fn (ClientModule $record): string => $record->enabled ? 'heroicon-o-x-circle' : 'heroicon-o-check-circle')
                        ->color(fn (ClientModule $record): string => $record->enabled ? 'danger' : 'success')
                        ->action(function (ClientModule $record): void {
                            $record->update(['enabled' => !$record->enabled]);
                        }),
                ]),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                    Tables\Actions\BulkAction::make('enable')
                        ->label('הפעל')
                        ->icon('heroicon-o-check-circle')
                        ->action(function (Builder $query): void {
                            $query->update(['enabled' => true]);
                        }),
                    Tables\Actions\BulkAction::make('disable')
                        ->label('השבת')
                        ->icon('heroicon-o-x-circle')
                        ->color('danger')
                        ->action(function (Builder $query): void {
                            $query->update(['enabled' => false]);
                        }),
                ]),
            ])
            ->defaultSort('position', 'asc');
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListClientModules::route('/'),
            'create' => Pages\CreateClientModule::route('/create'),
            'edit' => Pages\EditClientModule::route('/{record}/edit'),
        ];
    }
}